@app.route('/api/badge/<wallet>', methods=['GET'])
def get_badge(wallet):
    """Get mining status badge for a wallet in shields.io format"""
    if not wallet or len(wallet) < 10:
        return jsonify({
            "schemaVersion": 1,
            "label": "RustChain",
            "message": "Invalid wallet",
            "color": "red"
        }), 400

    try:
        # Get balance
        with sqlite3.connect(DB_PATH) as c:
            row = c.execute("SELECT COALESCE(amount_i64, 0) FROM balances WHERE miner_pk = ? OR miner_id = ?", (wallet, wallet)).fetchone()
            if not row:
                balance_rtc = 0.0
            else:
                balance_i64 = row[0] if row[0] else 0
                balance_rtc = balance_i64 / 1000000.0

        # Get current epoch
        epoch = slot_to_epoch(current_slot())
        
        # Determine mining status
        if balance_rtc > 0:
            status = "Active"
            color = "brightgreen"
        else:
            status = "Inactive"
            color = "red"

        message = f"{balance_rtc:.1f} RTC | Epoch {epoch} | {status}"

        return jsonify({
            "schemaVersion": 1,
            "label": "RustChain",
            "message": message,
            "color": color
        })

    except Exception as e:
        return jsonify({
            "schemaVersion": 1,
            "label": "RustChain",
            "message": "Error",
            "color": "red"
        }), 500